/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.learnbyproject.helper;

public class Keys {
    
    // These are used for attribute keys
    public static final String ERROR = "error";
    public static final String SUCCESS = "success";
    public static final String USER = "user";
    public static final String CURRENT_URL = "current-url";
    public static final String FRIEND_LIST = "friendlist";
    public static final String SUGGESTED_FRIEND_LIST = "suggestedfriendlist";
}
