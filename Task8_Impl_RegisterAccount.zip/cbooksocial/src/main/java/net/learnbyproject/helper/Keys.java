package net.learnbyproject.helper;
public class Keys {   
    // These are used for attribute keys
    public static final String ERROR = "ERROR";
}
