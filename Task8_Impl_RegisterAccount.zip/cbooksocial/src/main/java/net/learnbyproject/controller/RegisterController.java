
package net.learnbyproject.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.learnbyproject.helper.Keys;
import net.learnbyproject.helper.Validator;
import net.learnbyproject.service.UserService;

@WebServlet(urlPatterns = {"/register"})
public class RegisterController extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String firstName = request.getParameter("first-name").trim();
            String lastName = request.getParameter("last-name").trim();
            String emailOrMobile = request.getParameter("mobile-or-email").trim();
            String password = request.getParameter("user-password").trim();
            String day = request.getParameter("day").trim();
            String month = request.getParameter("month").trim();
            String year = request.getParameter("year").trim();
            String sex = request.getParameter("sex").trim();
            RequestDispatcher dis = request.getRequestDispatcher("register.jsp");
            if (!Validator.checkName(firstName)) {
                request.setAttribute(Keys.ERROR, "First name is invalid");
                dis.forward(request, response);
            } else if (!Validator.checkName(lastName)) {
                request.setAttribute(Keys.ERROR, "Last name is invalid");
                dis.forward(request, response);
            } else if (!Validator.checkEmailOrPhone(emailOrMobile)) {
                request.setAttribute(Keys.ERROR, "Email is invalid");
                dis.forward(request, response);
            } else if (!Validator.checkPassword(password)) {
                request.setAttribute(Keys.ERROR, "Password is invalid [mix: 4, max: 8, one digit, one upper case]");
                dis.forward(request, response);
            } else if (UserService.isDuplicateEmailOrPhone(emailOrMobile)) {
                request.setAttribute(Keys.ERROR, "Email/Phone is duplicated");
                dis.forward(request, response);
            } else {
                String birthday = String.format("%s-%s-%s", day, month, year);
                // Add to database
                if (UserService.addNewUser(firstName, lastName, emailOrMobile,
                            password, birthday, sex) == Validator.SUCCESS) {
                    response.sendRedirect("login.jsp");
                }
                else {
                    request.setAttribute(Keys.ERROR, "Something wrong! Please, try again!");
                    dis.forward(request, response);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(RegisterController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

}
