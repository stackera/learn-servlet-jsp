/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.learnbyproject.helper;

/**
 *
 * @author Admin
 */
public class Keys {
    
    // These are used for attribute keys
    public static final String ERROR = "ERROR";
    public static final String SUCCESS = "success";
    public static final String USER = "user";
}
