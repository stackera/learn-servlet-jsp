
package net.learnbyproject.helper;

public class Keys {
    
    // These are used for attribute keys
    public static final String ERROR = "error";
    public static final String SUCCESS = "success";
    public static final String USER = "user";
    public static final String CURRENT_URL = "current-url";
}
