package net.learnbyproject.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import net.learnbyproject.model.User;

public class UserService {

    public static boolean isDuplicateEmailOrPhone(String emailOrMobile) throws SQLException {
        String select = "select id from tbl_user where email_mobile = ?";
        try (Connection c = DBService.openConnection();
                PreparedStatement pStmt = c.prepareStatement(select);) {
            pStmt.setString(1, emailOrMobile);
            return pStmt.executeQuery().next();
        }
    }

    public static int addNewUser(String firstName, String lastName, String emailOrMobile,
                            String password, String birthday, String sex) throws SQLException {
        String insert = "Insert into tbl_user Values(null,?,?,?,?,?,?,null)";
        try (Connection c = DBService.openConnection();
                PreparedStatement pStmt = c.prepareStatement(insert)) {
            pStmt.setString(1, firstName);
            pStmt.setString(2, lastName);
            pStmt.setString(3, emailOrMobile);
            pStmt.setString(4, password);
            pStmt.setString(5, birthday); 
            pStmt.setString(6, sex);
            return pStmt.executeUpdate();
        } 
    }

}
